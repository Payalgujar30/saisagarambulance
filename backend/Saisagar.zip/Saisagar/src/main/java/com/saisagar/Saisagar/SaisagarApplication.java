package com.saisagar.Saisagar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaisagarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaisagarApplication.class, args);
	}

}
