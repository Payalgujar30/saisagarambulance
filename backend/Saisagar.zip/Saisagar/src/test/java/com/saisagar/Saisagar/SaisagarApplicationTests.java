package com.saisagar.Saisagar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaisagarApplicationTests {

	@Test
	void contextLoads() {
	}

}
